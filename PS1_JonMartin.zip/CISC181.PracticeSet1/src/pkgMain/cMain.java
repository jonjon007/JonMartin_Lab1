package pkgMain;

public class cMain {

	public static void main(String[] args) {
		/*
		 * Github Account Name : jonjon007
		 */
		Rectangle rec = new Rectangle(1.5, 2.5);		
		System.out.println("Rectangle Area: " + rec.Area());
	}

}
